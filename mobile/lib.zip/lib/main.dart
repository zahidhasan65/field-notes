import 'package:flutter/material.dart';

import 'app/app.dart';
import 'app/app_dependencies.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(FieldNotesApp(deps: AppDependencies()));
}
